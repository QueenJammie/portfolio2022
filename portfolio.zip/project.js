function darkBackground() {
    let body = document.querySelector("body");
    body.classList.add("dark");
    let lastA = document.querySelector(".a3");
    lastA.classList.add("a3Dark");
}

let darkTheme = document.querySelector("button.themeButton");
darkTheme.addEventListener("click", darkBackground);